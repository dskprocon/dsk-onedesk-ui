// Example: src/pages/Partition.js

import React from "react";

function Attendance() {
    return (
        <div className="p-10 text-center">
            <h1 className="text-3xl font-bold text-gray-800">📁 Partition System</h1>
            <p className="text-gray-500 mt-2">Coming soon...</p>
        </div>
    );
}

export default Partition;
